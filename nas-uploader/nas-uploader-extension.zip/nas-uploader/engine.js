// The engine: a hidden offscreen document that owns the long-running work — indexing the project folders,
// drafting email replies, Power Automate polling and the assistant chat. It is a normal window context, so
// it can use folder handles, DOMParser and pdf.js, and it is not stopped after 30 s idle the way the service
// worker is. (Mirroring itself runs in "NAS files", which has to stay open for big uploads anyway.)

import { getSettings, kvGet, kvSet, getAll, log } from './lib/db.js';
import { runIndex, applyDeepIndex } from './lib/indexer.js';
import { search, indexSummary, RECENCY_WORDS } from './lib/index.js';
import { getRootHandle, permissionState } from './lib/fsutil.js';
import { processEmail, regenerate, decideRequest, runItemAction, applyFolderResults, teachSource, listItems, summarize } from './lib/assistant.js';
import { pollFolderResponses } from './lib/automate.js';
import { listModels, listLocalModels, hasKey, activeModel, spentToday, spendReport, stopAllAI, resumeAI, pickGeminiFlash, generateText } from './lib/llm.js';
import { canCrossCheck, crossCheckMode } from './lib/crosscheck.js';
import { projectFolders } from './lib/folders.js';
import { nasClient, configProblem, writeTextFile } from './lib/nas.js';
import { sendChat, chatHistory, clearChat, runPendingTest } from './lib/chat.js';
import { listChanges, undoChange } from './lib/memory.js';
import { CONFIG, loadConfig } from './lib/config-store.js';
import { indexEmail } from './lib/mailindex.js';
import { invoiceReport, saveInvoiceReport, priorityList, setDone, addOwnTask } from './lib/todo.js';

const ui = (type, data) => chrome.runtime.sendMessage({ to: 'ui', type, ...data }).catch(() => {});
const bg = (type, data) => chrome.runtime.sendMessage({ to: 'bg', type, ...data }).catch(() => {});

// ---------- job runner: one file-system job at a time ----------

let job = null; // {name, started, controller, progress}
let indexAgain = false; // a reindex was asked for while another job ran

function startJob(name, fn) {
  if (job) {
    if (name === 'index') indexAgain = true;
    return { busy: true, job: job.name };
  }
  const controller = new AbortController();
  job = { name, started: Date.now(), controller, progress: null };
  const onProgress = (p) => {
    if (job) job.progress = p;
    ui('progress', { job: name, progress: p });
  };
  (async () => {
    try {
      const result = await fn({ signal: controller.signal, onProgress });
      ui('jobDone', { job: name, result: strip(result) });
    } catch (err) {
      await log('error', `${name}: ${err.message}`);
      ui('jobDone', { job: name, error: err.message });
    } finally {
      job = null;
      ui('status', {});
      if (indexAgain) {
        indexAgain = false;
        startJob('index', doIndex);
      }
    }
  })();
  return { started: true, job: name };
}

function strip(result) {
  if (!result || typeof result !== 'object') return result;
  const { L, N, ...rest } = result;
  return rest;
}

// ---------- folders and index ----------

async function indexRoots() {
  const folders = (await projectFolders()).filter((f) => f.index);
  const granted = folders.filter((f) => f.perm === 'granted');
  if (!granted.length) {
    if (folders.length) throw new Error('Chrome needs your OK to read the project folders again — click "Reconnect folders" in the side panel.');
    throw new Error('No project folders yet. Add one with "Mirror a folder" (it is mirrored to the NAS and indexed here).');
  }
  return granted.map((f) => ({ root: f.handle, prefix: f.prefix, folderId: f.id, projectMode: f.projectMode }));
}

// The deep (OCR) index is built on the NAS by the HP (or a Pi) and fetched over WebDAV. Its size and date are
// checked first, so an unchanged index costs one small request instead of a download.
async function deepSource(settings, { force = false } = {}) {
  let stamp = null;
  return {
    get: async () => {
      const client = await nasClient();
      const st = await client.stat(settings.deepIndexFile);
      if (!st || st.isDir) return null;
      stamp = `${st.size}|${st.modified?.getTime() || 0}`;
      if (!force && (await kvGet('deepRemoteStamp')) === stamp) return { upToDate: true };
      return client.getBlob(settings.deepIndexFile);
    },
    done: async () => {
      if (stamp) await kvSet('deepRemoteStamp', stamp);
    },
    from: 'NAS',
  };
}

// Tells the HP which NAS folders are project folders, so its OCR job reads only those (never the media library).
async function publishProjectFolders() {
  const settings = await getSettings();
  const folders = (await projectFolders({ withPerm: false })).filter((f) => f.index).map((f) => f.nasPath).sort();
  const nasOnly = (settings.nasFolders || []).map((p) => `/${String(p).replace(/^\/+|\/+$/g, '')}`).filter((p) => p !== '/').sort();
  const stamp = JSON.stringify({ folders, nasOnly });
  if ((await kvGet('projectFoldersPublished')) === stamp) return;
  const client = await nasClient();
  await writeTextFile(client, '/.assistant/project-folders.json', JSON.stringify({ updated: new Date().toISOString(), folders, nasOnly }, null, 2), 'application/json; charset=utf-8');
  await kvSet('projectFoldersPublished', stamp);
}

async function doIndex({ signal, onProgress }) {
  const settings = await getSettings();
  // NAS-only folders (standards copied from Drive, …) work without any local project folder.
  if ((settings.nasFolders || []).length && !(await projectFolders().catch(() => [])).some((f) => f.index && f.perm === 'granted')) {
    if (!configProblem()) await publishProjectFolders().catch((err) => log('error', `publishing project folders: ${err.message}`));
    return { files: (await getAll('files')).length, nasOnly: true, deep: await doDeep({ signal, onProgress, force: false, settings }) };
  }
  const roots = await indexRoots();
  if (!configProblem()) await publishProjectFolders().catch((err) => log('error', `publishing project folders: ${err.message}`));
  const status = await runIndex(roots, settings, { signal, onProgress, rootName: 'local' });
  if (!signal.aborted && !configProblem()) status.deep = await doDeep({ signal, onProgress, force: false, settings });
  return status;
}

async function doDeep({ signal, onProgress, force, settings }) {
  settings = settings || (await getSettings());
  const src = await deepSource(settings, { force });
  const res = await applyDeepIndex(src.get, settings, { signal, onProgress, force, from: src.from });
  if (res.found && !res.error && !signal?.aborted) await src.done();
  return res;
}

// ---------- email queue (one draft at a time) ----------

const queue = [];
let draining = false;
const onItem = (item) => {
  ui('item', { id: item.id, status: item.status });
updateBadge();
};

async function drain() {
  if (draining) return;
  draining = true;
  try {
    while (queue.length) {
      // Stop AI: emails not started yet wait in the queue until Resume AI.
      if ((await getSettings()).aiPaused) break;
      const { email, force } = queue.shift();
      try {
        await processEmail(email, { force, onChange: onItem });
      } catch (err) {
        await log('error', `process: ${err.message}`);
      }
    }
  } finally {
    draining = false;
  }
}

async function updateBadge() {
  const items = await listItems();
  const n = items.filter((i) => ['needs-info', 'needs-approval', 'ready'].includes(i.status)).length;
  bg('badge', { text: n ? String(n) : '' });
}

// ---------- chat (one reply at a time) ----------

let chatBusy = null; // AbortController of the reply being written

async function doChat(text) {
  if (chatBusy) return { busy: true };
  chatBusy = new AbortController();
  const signal = chatBusy.signal;
  (async () => {
    try {
      const reply = await sendChat(text, { signal, onUpdate: (m) => ui('chat', { message: m }) });
      if (reply.reindex) startJob('index', doIndex);
    } catch (err) {
      await log('error', `chat: ${err.message}`);
      ui('chat', { error: err.message });
    } finally {
      chatBusy = null;
    }
  })();
  return { started: true };
}

// ---------- timers ----------

let lastAutoIndex = 0;

async function tick() {
  const settings = await getSettings();
  try {
    const results = await pollFolderResponses();
    if (results.length) await applyFolderResults(results, { onChange: onItem });
  } catch (err) {
    await log('error', `bridge poll: ${err.message}`);
  }
  if (job) return;
  const now = Date.now();
  const idx = (await kvGet('indexStatus'))?.at || 0;
  if (settings.autoIndexMinutes > 0 && now - Math.max(idx, lastAutoIndex) > settings.autoIndexMinutes * 60000) {
    lastAutoIndex = now;
    try {
      await indexRoots();
      startJob('index', doIndex);
    } catch {
      /* folders not connected */
    }
  }
}

// ---------- status ----------

async function status() {
  const settings = await getSettings();
  const bridge = await getRootHandle('bridge');
  const items = await listItems();
  const folders = await projectFolders().catch(() => []);
  return {
    provider: settings.provider,
    model: activeModel(settings),
    hasKey: hasKey(settings),
    keys: { anthropic: !!settings.anthropicKey, gemini: !!settings.geminiKey },
    folders: {
      bridge: bridge ? { name: bridge.name, perm: await permissionState(bridge) } : null,
    },
    projectFolders: folders.map((f) => ({ id: f.id, name: f.name, nasPath: f.nasPath, perm: f.perm, index: f.index, projectMode: f.projectMode, lastSync: f.lastSync })),
    nas: { configured: !configProblem(), problem: configProblem(), url: CONFIG.serverUrl },
    index: await indexSummary(),
    deep: await kvGet('deepApplied'),
    job: job ? { name: job.name, started: job.started, progress: job.progress } : null,
    queue: queue.length + (draining ? 1 : 0),
    ai: {
      paused: !!settings.aiPaused,
      spentToday: await spentToday(),
      spend: await spendReport(),
      dailyBudgetUsd: Number(settings.dailyBudgetUsd) || 0,
      crossCheck: canCrossCheck(settings),
      crossCheckMode: crossCheckMode(settings),
      crossCheckOff: settings.crossCheck === false,
    },
    chatBusy: !!chatBusy,
    pendingActions: ((await kvGet('pendingActions')) || []).length,
    summary: summarize(items),
    actions: (settings.actions || []).filter((a) => a.enabled !== false).map((a) => ({ name: a.name, kind: a.kind || 'read', description: a.description || '', params: a.params || '' })),
  };
}

// ---------- message handling ----------

const handlers = {
  ping: async () => ({ ok: true }),
  // The kill switch: cancels every Claude/Gemini call in progress (here, in the meeting window, anywhere) and
  // refuses new ones until Resume.
  'ai.stop': async () => {
    await stopAllAI();
    ui('aiState', { paused: true });
    return { paused: true };
  },
  'ai.resume': async () => {
    await resumeAI();
    ui('aiState', { paused: false });
    drain();
    return { paused: false };
  },
  status,
  'index.run': async () => startJob('index', doIndex),
  'deep.apply': async (m) => startJob('deep', (o) => doDeep({ ...o, force: !!m.force })),
  'job.stop': async () => {
    if (job) job.controller.abort();
    return { ok: true };
  },
  // Local search — no tokens. Meeting prompts, the chat and the Files tab all use it.
  search: async (m) => ({
    hits: await search(m.q || '', {
      k: m.k || 12,
      charBudget: m.charBudget || 20000,
      perFile: m.perFile || 2,
      maxChunkChars: m.maxChunkChars || 400,
      boostPrefixes: m.projects || [],
      preferRecent: m.preferRecent ?? RECENCY_WORDS.test(m.q || ''),
      excludePaths: m.excludePaths ? new Set(m.excludePaths) : null,
    }),
  }),
  'nas.test': async () => {
    try {
      const client = await nasClient();
      const entries = await client.list('/');
      return { ok: true, entries: entries.length };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  },
  'email.capture': async (m) => {
    if (!m.email) return { error: 'no email' };
    queue.push({ email: m.email, force: !!m.force });
    drain();
    return { queued: true };
  },
  'item.regenerate': async (m) => regenerate(m.id, { notes: m.notes, effort: m.effort, onChange: onItem }),
  'item.reprocess': async (m) => {
    const item = (await getAll('items')).find((i) => i.id === m.id);
    if (!item) return { error: 'not found' };
    queue.push({ email: { ...item, body: item.bodyRaw || item.bodyClean }, force: true });
    drain();
    return { queued: true };
  },
  'item.decide': async (m) => decideRequest(m.id, m.key, m.approve, { params: m.params, onChange: onItem }),
  'item.action': async (m) => runItemAction(m.id, m.action, m.params || {}, { onChange: onItem }),
  'item.teach': async (m) => teachSource(m.id, m.path, m.kind, { onChange: onItem }),
  // To do: the priority list and the invoice summary.
  'todo.priorities': async () => priorityList(),
  'todo.last': async () => (await kvGet('priorities:last')) || null,
  'todo.done': async (m) => setDone(m.id, !!m.done),
  'todo.addTask': async (m) => addOwnTask(m.text, m.due || ''),
  'todo.invoices': async (m) => {
    const rep = await invoiceReport(m.month);
    if (rep.invoices.length) {
      rep.savedTo = await saveInvoiceReport(rep).catch((err) => `not saved (${err.message})`);
      await kvSet(`invoices:${rep.month}`, rep);
    }
    return rep;
  },
  // "Index these emails" in Outlook on the web: one email at a time, no AI.
  'mail.index': async (m) => indexEmail(m.email),
  'llm.models': async (m) => {
    const settings = { ...(await getSettings()), ...(m.override || {}) };
    const provider = m.provider || settings.provider;
    if (provider === 'local') return { models: await listLocalModels(settings), auto: '' };
    const models = await listModels(settings, provider);
    return { models, auto: provider === 'gemini' ? pickGeminiFlash(models) || '' : '' };
  },
  // Settings → "Test web search": one small search with the chosen model.
  'llm.webtest': async (m) => {
    const settings = await getSettings();
    const provider = m.provider || settings.provider;
    const r = await generateText({ ...settings, _tag: 'test' }, { provider, web: true, effort: 'low', maxTokens: 300, system: 'Answer in one short sentence.', prompt: 'Search the web: what is the latest stable version of Google Chrome?' });
    return { model: r.model, sources: r.sources.length, text: r.text.trim().slice(0, 140) };
  },
  'chat.send': async (m) => doChat(m.text || ''),
  'chat.stop': async () => {
    chatBusy?.abort();
    return { ok: true };
  },
  'chat.history': async () => ({ messages: await chatHistory(), busy: !!chatBusy }),
  'chat.clear': async () => {
    await clearChat();
    return { ok: true };
  },
  'chat.runTest': async (m) => runPendingTest(m.messageId, m.testId),
  'changes.list': async () => ({ changes: await listChanges(40) }),
  'changes.undo': async (m) => {
    const rec = await undoChange(m.id);
    if (/^set_folder_options$/.test(rec.tool)) startJob('index', doIndex);
    return { ok: true, change: rec };
  },
  tick: async () => {
    await tick();
    return { ok: true };
  },
  badge: async () => {
    await updateBadge();
    return { ok: true };
  },
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.to !== 'engine') return false;
  const h = handlers[msg.type];
  if (!h) {
    sendResponse({ error: `unknown engine message ${msg.type}` });
    return false;
  }
  Promise.resolve()
    .then(() => h(msg))
    .then((res) => sendResponse(res ?? { ok: true }))
    .catch((err) => sendResponse({ error: err.message || String(err), kind: err.kind }));
  return true;
});

// Resume AI (from any page): drafts that waited in the queue go ahead.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'ai.resumed') drain();
  return false;
});

await loadConfig();
updateBadge();
