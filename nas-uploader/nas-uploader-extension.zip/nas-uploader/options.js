import { getSettings, saveSettings, clear, kvSet, get, DEFAULT_SETTINGS } from './lib/db.js';
import { getRootHandle, setRootHandle, permissionState, requestPermission } from './lib/fsutil.js';
import { getRules, deleteRule, addHint } from './lib/teach.js';
import { splitList } from './lib/text.js';
import { projectFolders } from './lib/folders.js';
import { listInstructions, addInstruction, removeInstruction } from './lib/memory.js';
import { CONFIG, loadConfig, forgetSavedConfig } from './lib/config-store.js';
import { modelChoices, fillModelSelect } from './lib/models.js';
import { suggestKeywords } from './lib/projects.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const bg = (type, data = {}) => chrome.runtime.sendMessage({ to: 'bg', type, ...data });
const engine = (type, data = {}) => bg('engine', { payload: { type, ...data } });

let settings = null;

let toastTimer = null;
function toast(msg, ms = 3500) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, ms);
}

function flashSaved() {
  $('saved').textContent = `Saved ${new Date().toLocaleTimeString()}`;
}

// ---------------------------------------------------------------- simple fields

const NUMERIC = new Set(['localContextChars', 'snippetCount', 'snippetCharBudget', 'maxEmailChars', 'maxFileMB', 'maxCharsPerFile', 'autoIndexMinutes', 'meetingMinGapSec', 'dailyBudgetUsd', 'maxThreadChars']);
const NULLABLE = new Set(['priceInPerM', 'priceOutPerM']);

function readField(el) {
  const key = el.dataset.key;
  if (el.type === 'checkbox') return el.checked;
  if (el.type === 'radio') return el.value;
  if (NULLABLE.has(key)) return el.value === '' ? null : Number(el.value);
  if (NUMERIC.has(key)) return Number(el.value) || 0;
  return el.value;
}

function fillFields() {
  document.querySelectorAll('[data-key]').forEach((el) => {
    const v = settings[el.dataset.key];
    if (el.type === 'checkbox') el.checked = !!v;
    else if (el.type === 'radio') el.checked = el.value === v;
    else el.value = v ?? '';
  });
}

const pending = {};
let saveTimer = null;
function queueSave(el) {
  if (el.type === 'radio' && !el.checked) return;
  pending[el.dataset.key] = readField(el);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const patch = { ...pending };
    for (const k of Object.keys(pending)) delete pending[k];
    settings = await saveSettings(patch);
    // The same setting can appear in two sections (e.g. Background tasks and Meetings): keep them in step.
    for (const k of Object.keys(patch)) {
      document.querySelectorAll(`[data-key="${k}"]`).forEach((other) => {
        if (other === document.activeElement || other.type === 'radio') return;
        if (other.type === 'checkbox') other.checked = !!settings[k];
        else other.value = settings[k] ?? '';
      });
    }
    flashSaved();
  }, 300);
}

document.addEventListener('input', (e) => { if (e.target.dataset?.key) queueSave(e.target); });
document.addEventListener('change', (e) => { if (e.target.dataset?.key) queueSave(e.target); });

// ---------------------------------------------------------------- the local model on the HP

function renderLocalFor() {
  const lf = settings.localFor || {};
  document.querySelectorAll('[data-local-for]').forEach((b) => { b.checked = !!lf[b.dataset.localFor]; });
}
document.querySelectorAll('[data-local-for]').forEach((b) => b.addEventListener('change', async () => {
  settings = await saveSettings({ localFor: { ...(settings.localFor || {}), [b.dataset.localFor]: b.checked } });
  flashSaved();
}));
$('localTest').addEventListener('click', async () => {
  await new Promise((r) => setTimeout(r, 350));
  $('localOut').textContent = 'Connecting…';
  const res = await engine('llm.models', { provider: 'local' }).catch((err) => ({ error: err.message }));
  if (res?.error) { $('localOut').innerHTML = `<span class="err">${esc(res.error)}</span>`; return; }
  $('localModels').innerHTML = (res.models || []).map((m) => `<option value="${esc(m)}"></option>`).join('');
  $('localOut').textContent = `Connected · models: ${(res.models || []).join(', ') || 'none listed'}`;
});

// ---------------------------------------------------------------- background tasks & cost

const FEATURE = { email: 'Email drafts', check: 'Second checks', meeting: 'Meeting prompts & answers', research: 'Meeting research', minutes: 'Minutes', lookup: 'Web look-ups', transcription: 'Gemini transcription', chat: 'Chat', agent: 'Browser agent', invoices: 'Invoice summaries', priorities: 'Priority lists', other: 'Other' };
const usd = (n) => (n < 0.01 && n > 0 ? `$${n.toFixed(4)}` : `$${(n || 0).toFixed(2)}`);

async function renderSpend() {
  let st = null;
  try { st = await engine('status'); } catch { /* engine starting */ }
  const sp = st?.ai?.spend;
  if (!sp) { $('spendBox').textContent = ''; return; }
  const rows = Object.entries(sp.byFeature || {}).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<tr><td>${esc(FEATURE[k] || k)}</td><td>${usd(v)}</td></tr>`).join('');
  $('spendBox').innerHTML = `<b>Spent (estimated from token counts):</b> today ${usd(sp.today)} · this month ${usd(sp.month)}${rows ? `<table class="jobs"><tbody>${rows}</tbody></table>` : ' · nothing yet this month'}`;
}

const PRESETS = {
  saver: { processOnOpen: false, autoScan: false, emailEffort: 'low', refinePass: false, crossCheck: false, crossCheckRevise: false, dualLookUp: false, meetingPrompts: 'manual', meetingWebLookup: false, meetingSummary: false, meetingStt: 'whisper', effort: 'low' },
  balanced: { processOnOpen: true, autoScan: false, emailEffort: 'medium', refinePass: true, crossCheck: true, crossCheckRevise: true, dualLookUp: false, meetingPrompts: 'auto', meetingWebLookup: true, meetingSummary: true, meetingStt: 'whisper', effort: 'low' },
  best: { processOnOpen: true, autoScan: true, emailEffort: 'high', refinePass: true, crossCheck: true, crossCheckRevise: true, dualLookUp: true, meetingPrompts: 'auto', meetingWebLookup: true, meetingSummary: true, effort: 'medium' },
};
document.querySelectorAll('[data-preset]').forEach((b) => b.addEventListener('click', async () => {
  const patch = { ...PRESETS[b.dataset.preset] };
  if (b.dataset.preset === 'best') patch.meetingStt = settings.geminiKey ? 'both' : 'whisper';
  settings = await saveSettings(patch);
  fillFields();
  $('presetOut').textContent = `${b.textContent.trim()} applied.`;
  flashSaved();
  renderAccuracy();
}));

// ---------------------------------------------------------------- accuracy & safety

async function renderAccuracy() {
  const s = settings || (await getSettings());
  const both = !!(s.anthropicKey && s.geminiKey);
  const one = s.anthropicKey ? 'Claude' : s.geminiKey ? 'Gemini' : '';
  $('xcState').textContent = s.crossCheck === false ? 'The second check is off: only the free checks run.'
    : both ? '✓ Both keys are set: Claude and Gemini check each other.'
      : one && s.localFor?.check && s.localUrl && s.localModel ? `✓ One key: your local model on the HP checks ${one}'s work (free; a long check goes to a separate ${one} review).`
      : one ? `✓ One key: a second, separate ${one} review checks its work. Add the other provider's key to have Claude and Gemini check each other (more independent).`
        : 'No AI key yet: only the free checks run.';
  let st = null;
  try { st = await engine('status'); } catch { /* engine starting */ }
  const ai = st?.ai;
  const paused = ai ? ai.paused : !!s.aiPaused;
  $('aiToggle').textContent = paused ? '▶ Resume AI' : '⏹ Stop AI';
  $('aiToggle').className = paused ? 'primary' : 'danger';
  $('spendState').textContent = ai ? `Spent today (estimated from token counts): $${(ai.spentToday || 0).toFixed(2)}${ai.dailyBudgetUsd ? ` of $${ai.dailyBudgetUsd.toFixed(2)}` : ''}.${paused ? ' AI is stopped.' : ''}` : '';
}

$('aiToggle').addEventListener('click', async () => {
  const s = await getSettings();
  const res = await engine(s.aiPaused ? 'ai.resume' : 'ai.stop');
  if (res?.error) { toast(res.error, 6000); return; }
  settings = await getSettings();
  toast(settings.aiPaused ? 'AI stopped everywhere.' : 'AI resumed.');
  renderAccuracy();
});
document.addEventListener('change', (e) => {
  if (['crossCheck', 'anthropicKey', 'geminiKey', 'dailyBudgetUsd'].includes(e.target.dataset?.key)) setTimeout(renderAccuracy, 500);
});

document.querySelectorAll('[data-reveal]').forEach((b) => b.addEventListener('click', () => {
  const inp = document.querySelector(`[data-key="${b.dataset.reveal}"]`);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  b.textContent = inp.type === 'password' ? 'Show' : 'Hide';
}));

// ---------------------------------------------------------------- project emails (people and keywords)

async function renderProjectMail() {
  const { kvGet } = await import('./lib/db.js');
  const projects = (await kvGet('projects')) || [];
  const rules = settings.projectMail || {};
  $('projectMailList').innerHTML = projects.length ? projects.map((p) => `<div class="pm-row" data-project="${esc(p)}">
      <b title="${esc(p)}">${esc(p.split('/').pop())}</b>
      <label class="field"><span>People</span><input type="text" data-pm="people" value="${esc(rules[p]?.people || '')}" placeholder="Dana Lee, pm@arcticfresh.ca, @client.ca"></label>
      <label class="field"><span>Keywords</span><input type="text" data-pm="keywords" value="${esc(rules[p]?.keywords || '')}" placeholder="${esc(suggestKeywords(p) || 'project number, name, site')}"></label>
    </div>`).join('') : '<p class="small muted">No projects yet: they appear once a project folder is mirrored and indexed.</p>';
}

$('projectMailList').addEventListener('change', async (e) => {
  const inp = e.target.closest('[data-pm]');
  const row = e.target.closest('[data-project]');
  if (!inp || !row) return;
  const rules = { ...(settings.projectMail || {}) };
  rules[row.dataset.project] = { ...(rules[row.dataset.project] || {}), [inp.dataset.pm]: inp.value.trim() };
  settings = await saveSettings({ projectMail: rules });
  flashSaved();
});

// ---------------------------------------------------------------- model pickers

const MODEL_KEY = { anthropic: 'anthropicModel', gemini: 'geminiModel' };
const DEFAULT_MODELS = { anthropic: ['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5'], gemini: [] };
const modelLists = {};

/** Fills a provider's model picker from the models its key can use (or a short default list without a key). */
async function renderModelPicker(provider, { reload = false } = {}) {
  const s = settings || (await getSettings());
  const sel = $(`model-${provider}`);
  let list = modelLists[provider];
  if ((!list || reload) && s[provider === 'gemini' ? 'geminiKey' : 'anthropicKey']) {
    const res = await engine('llm.models', { provider }).catch((err) => ({ error: err.message }));
    if (!res?.error) list = modelLists[provider] = { models: res.models || [], auto: res.auto || '' };
    else if (reload) throw new Error(res.error);
  }
  const choices = modelChoices(provider, list?.models?.length ? list.models : DEFAULT_MODELS[provider], { autoModel: list?.auto });
  fillModelSelect(sel, choices, s[MODEL_KEY[provider]]);
  $(`model-other-${provider}`).hidden = sel.value !== '__other';
  return list;
}

document.querySelectorAll('[data-model]').forEach((sel) => sel.addEventListener('change', async () => {
  const provider = sel.dataset.model;
  const other = $(`model-other-${provider}`);
  if (sel.value === '__other') {
    other.hidden = false;
    other.focus();
    return;
  }
  other.hidden = true;
  settings = await saveSettings({ [MODEL_KEY[provider]]: sel.value });
  flashSaved();
}));
document.querySelectorAll('[data-model-other]').forEach((inp) => inp.addEventListener('change', async () => {
  const provider = inp.dataset.modelOther;
  const v = inp.value.trim().replace(/^models\//, '');
  if (!v) return;
  settings = await saveSettings({ [MODEL_KEY[provider]]: v });
  flashSaved();
  await renderModelPicker(provider);
}));

document.querySelectorAll('[data-test]').forEach((b) => b.addEventListener('click', async () => {
  const provider = b.dataset.test;
  const out = document.querySelector(`[data-testout="${provider}"]`);
  await new Promise((r) => setTimeout(r, 350)); // let a just-typed key save
  settings = await getSettings();
  out.textContent = 'Testing…';
  try {
    const list = await renderModelPicker(provider, { reload: true });
    out.textContent = `Key works · ${list?.models?.length || 0} models — pick one above.`;
  } catch (err) {
    out.innerHTML = `<span class="err">${esc(err.message)}</span>`;
  }
}));

// One tiny search, so you can see whether web look-ups work with this key and model.
document.querySelectorAll('[data-webtest]').forEach((b) => b.addEventListener('click', async () => {
  const provider = b.dataset.webtest;
  const out = document.querySelector(`[data-testout="${provider}"]`);
  out.textContent = 'Searching the web…';
  const res = await engine('llm.webtest', { provider }).catch((err) => ({ error: err.message }));
  out.innerHTML = res?.error
    ? `<span class="err">Web search failed: ${esc(res.error)}</span>`
    : `✓ Web search works with ${esc(res.model)}: ${res.sources} source${res.sources === 1 ? '' : 's'} found (“${esc(res.text)}”).`;
}));

// ---------------------------------------------------------------- folders

async function renderFolders() {
  const h = await getRootHandle('bridge');
  const el = $('f-bridge');
  if (!h) {
    el.innerHTML = '<span class="pill">not set</span>';
  } else {
    const p = await permissionState(h);
    el.innerHTML = `<b>${esc(h.name)}</b> ${p === 'granted' ? '<span class="pill ok">connected</span>' : '<button type="button" data-grant="bridge">Grant access</button>'}`;
  }
  await renderFolderList();
}

async function renderFolderList() {
  const folders = await projectFolders();
  if (!folders.length) {
    $('folderList').innerHTML = '<p class="small muted">No project folders yet. Click "Mirror a folder…", choose the folder (or the drive folder) that holds your projects, and pick where it goes on the NAS.</p>';
    return;
  }
  $('folderList').innerHTML = folders.map((f) => {
    const state = f.perm === 'granted' ? '<span class="pill ok">connected</span>' : f.perm === 'missing' ? '<span class="pill bad">folder lost — mirror it again</span>' : `<button type="button" data-grant-folder="${esc(f.id)}">Grant access</button>`;
    return `<div class="action-card" data-folder="${esc(f.id)}">
      <div class="row"><b class="grow">📁 ${esc(f.name)} → ${esc(f.nasPath)}</b>${state}</div>
      <div class="row">
        <label class="check small"><input type="checkbox" data-pref="index" ${f.index ? 'checked' : ''}> Index this folder</label>
        <label class="field small" style="min-width:260px"><span>Projects in this folder</span>
          <select data-pref="projectMode">
            <option value="subfolders" ${f.projectMode !== 'single' ? 'selected' : ''}>Each subfolder is a project</option>
            <option value="single" ${f.projectMode === 'single' ? 'selected' : ''}>The whole folder is one project</option>
          </select>
        </label>
      </div>
    </div>`;
  }).join('');
}

async function renderNas() {
  await loadConfig({ fresh: true });
  const url = CONFIG.serverUrl && !/your-nas\.example/.test(CONFIG.serverUrl) ? CONFIG.serverUrl : '';
  $('nasInfo').innerHTML = !url
    ? 'Not set up yet. Click below (or fill in <code>config.js</code> in the extension folder).'
    : CONFIG.source === 'config.js'
      ? `<b>${esc(url)}</b> as <b>${esc(CONFIG.username || '?')}</b> — built into <code>config.js</code> (change it there).`
      : `<b>${esc(url)}</b> as <b>${esc(CONFIG.username || '?')}</b> — saved on this computer${CONFIG.password ? ' with the password' : '; the password is asked once per browser session'}.`;
  $('nasChange').hidden = CONFIG.source === 'config.js' && !!url;
  $('nasForget').hidden = CONFIG.source !== 'settings';
}
$('nasChange').addEventListener('click', () => bg('app.open', { hash: '#nas-setup' }));
$('nasForget').addEventListener('click', async () => {
  if (!confirm('Forget the NAS address and login on this computer? Your files are not touched.')) return;
  await forgetSavedConfig();
  $('nasOut').textContent = 'Forgotten.';
  renderNas();
});

$('addFolder').addEventListener('click', () => bg('app.open', { hash: '#new-mirror' }));

$('saveNasFolders').addEventListener('click', async () => {
  const list = $('nasFolders').value.split(/[\n,]/).map((x) => x.trim()).filter(Boolean).map((x) => `/${x.replace(/^\/+|\/+$/g, '')}`).filter((x) => x !== '/');
  settings = await saveSettings({ nasFolders: [...new Set(list)] });
  $('nasFolders').value = settings.nasFolders.join('\n');
  $('nasFoldersOut').textContent = list.length ? 'Saved. The HP reads them on its next run (every 2 hours), then they appear in search.' : 'Saved.';
  engine('index.run');
});
$('openNasFiles').addEventListener('click', () => bg('app.open', { hash: '' }));

$('folderList').addEventListener('change', async (e) => {
  const key = e.target.dataset.pref;
  const card = e.target.closest('[data-folder]');
  if (!key || !card) return;
  const prefs = { ...(settings.folderPrefs || {}) };
  const cur = { ...(prefs[card.dataset.folder] || {}) };
  cur[key] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
  prefs[card.dataset.folder] = cur;
  settings = await saveSettings({ folderPrefs: prefs });
  flashSaved();
  engine('index.run');
});

$('folderList').addEventListener('click', async (e) => {
  const g = e.target.closest('[data-grant-folder]');
  if (!g) return;
  const f = (await projectFolders({ withPerm: false })).find((x) => x.id === g.dataset.grantFolder);
  if (f) await requestPermission(f.handle, 'read');
  await renderFolderList();
  engine('index.run');
});

document.addEventListener('click', async (e) => {
  const pick = e.target.closest('[data-pick]');
  if (pick) {
    const which = pick.dataset.pick;
    try {
      const h = await window.showDirectoryPicker({ id: `mm-${which}`, mode: 'readwrite' });
      await setRootHandle(which, h);
      toast(`${which} folder set to ${h.name}`);
    } catch (err) {
      if (err.name !== 'AbortError') toast(err.message, 6000);
    }
    renderFolders();
    return;
  }
  const grant = e.target.closest('[data-grant]');
  if (grant) {
    const h = await getRootHandle(grant.dataset.grant);
    await requestPermission(h);
    renderFolders();
  }
});

// ---------------------------------------------------------------- Outlook URLs

$('grantOutlook').addEventListener('click', async () => {
  const origins = splitList($('grantOutlook').closest('section').querySelector('[data-key="extraOutlookUrls"]').value);
  if (!origins.length) { $('grantOut').textContent = 'Add an address first.'; return; }
  try {
    const ok = await chrome.permissions.request({ origins });
    if (ok) await bg('scripts.sync');
    $('grantOut').textContent = ok ? 'Allowed. Reload that Outlook tab.' : 'Not allowed.';
  } catch (err) {
    $('grantOut').textContent = err.message;
  }
});

// ---------------------------------------------------------------- Power Automate actions

const ACTION_DEFAULTS = { name: '', description: '', kind: 'read', transport: 'http', url: '', params: '', autoRun: false, auto: false, timeoutSec: 300, enabled: true };

function actionCard(a, i) {
  return `<div class="action-card stack" data-i="${i}">
    <div class="grid3">
      <label class="field"><span>Name (short, no spaces)</span><input type="text" data-a="name" value="${esc(a.name)}" placeholder="sap_po_status"></label>
      <label class="field"><span>Type</span><select data-a="kind"><option value="read" ${a.kind !== 'write' ? 'selected' : ''}>Read — fetches data</option><option value="write" ${a.kind === 'write' ? 'selected' : ''}>Write — changes records</option></select></label>
      <label class="field"><span>Connection</span><select data-a="transport"><option value="http" ${a.transport !== 'folder' ? 'selected' : ''}>HTTP trigger URL</option><option value="folder" ${a.transport === 'folder' ? 'selected' : ''}>Bridge folder (OneDrive)</option></select></label>
    </div>
    <label class="field" ${a.transport === 'folder' ? 'hidden' : ''}><span>Flow URL (from "When an HTTP request is received")</span>
      <div class="row nowrap"><input type="url" class="grow" data-a="url" value="${esc(a.url)}" placeholder="https://prod-00.canadacentral.logic.azure.com/workflows/…"><button type="button" data-allow="${i}" hidden>Allow this address</button></div></label>
    <label class="field"><span>What it does / when to use it (the AI reads this)</span><textarea data-a="description" rows="2" placeholder="Returns SAP purchase-order status, amounts and vendor for a PO number. Use when an email asks about a PO, invoice or payment.">${esc(a.description)}</textarea></label>
    <label class="field"><span>Parameters — comma separated; "name: hint" or "name={{subject}}" to prefill from the email ({{subject}} {{from}} {{project}} {{summary}} {{status}} {{missing}} {{draft}} {{date}})</span><input type="text" data-a="params" value="${esc(a.params)}" placeholder="po_number: 10-digit SAP PO, project={{project}}"></label>
    <div class="row">
      <label class="check small" ${a.kind === 'write' ? 'hidden' : ''}><input type="checkbox" data-a="autoRun" ${a.autoRun ? 'checked' : ''}> Let the AI run this without asking</label>
      <label class="check small" ${a.kind === 'write' ? '' : 'hidden'}><input type="checkbox" data-a="auto" ${a.auto ? 'checked' : ''}> Run after every draft without asking (e.g. tracker log)</label>
      <label class="check small"><input type="checkbox" data-a="enabled" ${a.enabled !== false ? 'checked' : ''}> Enabled</label>
      <label class="field small" style="width:150px"><span>Timeout (s)</span><input type="number" min="10" data-a="timeoutSec" value="${esc(a.timeoutSec ?? 300)}"></label>
      <span class="grow"></span>
      <button type="button" class="danger" data-remove="${i}">Remove</button>
    </div>
  </div>`;
}

function originPattern(url) {
  try { return `${new URL(url).origin}/*`; } catch { return null; }
}

// Shows "Allow this address" for flow URLs the extension has no access to yet.
async function checkActionAccess() {
  for (const b of document.querySelectorAll('[data-allow]')) {
    const a = settings.actions[Number(b.dataset.allow)];
    const pattern = a && a.transport !== 'folder' ? originPattern(a.url) : null;
    b.hidden = !pattern || await chrome.permissions.contains({ origins: [pattern] }).catch(() => true);
  }
}

function renderActions() {
  const acts = settings.actions || [];
  $('actions').innerHTML = acts.length ? acts.map(actionCard).join('') : '<p class="small muted">No flows yet.</p>';
  checkActionAccess();
}

async function saveActions(rerender = false) {
  settings = await saveSettings({ actions: settings.actions });
  flashSaved();
  if (rerender) renderActions();
}

$('actions').addEventListener('input', (e) => {
  const card = e.target.closest('.action-card');
  const field = e.target.dataset.a;
  if (!card || !field) return;
  const a = settings.actions[Number(card.dataset.i)];
  a[field] = e.target.type === 'checkbox' ? e.target.checked : field === 'timeoutSec' ? Number(e.target.value) || 300 : e.target.value;
  if (field === 'name') a.name = a.name.trim().replace(/\s+/g, '_');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => saveActions(field === 'kind' || field === 'transport'), 300);
});
$('actions').addEventListener('change', (e) => {
  if (e.target.dataset.a === 'kind' || e.target.dataset.a === 'transport' || e.target.type === 'checkbox') {
    const card = e.target.closest('.action-card');
    const a = settings.actions[Number(card.dataset.i)];
    a[e.target.dataset.a] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    saveActions(true);
  }
});
$('actions').addEventListener('focusout', (e) => { if (e.target.dataset.a === 'url') checkActionAccess(); });
$('actions').addEventListener('click', async (e) => {
  const allow = e.target.closest('[data-allow]');
  if (allow) {
    const pattern = originPattern(settings.actions[Number(allow.dataset.allow)].url);
    const ok = pattern && await chrome.permissions.request({ origins: [pattern] }).catch(() => false);
    toast(ok ? 'Access allowed.' : 'Access not granted — the flow cannot be called.');
    checkActionAccess();
    return;
  }
  const r = e.target.closest('[data-remove]');
  if (!r) return;
  if (!confirm('Remove this flow from the assistant? (The flow itself is not touched.)')) return;
  settings.actions.splice(Number(r.dataset.remove), 1);
  saveActions(true);
});
$('addAction').addEventListener('click', () => {
  settings.actions = [...(settings.actions || []), { ...ACTION_DEFAULTS }];
  saveActions(true);
});
$('exportActions').addEventListener('click', async () => {
  await navigator.clipboard.writeText(JSON.stringify(settings.actions || [], null, 2));
  toast('Flow list copied as JSON.');
});
$('importActions').addEventListener('click', async () => {
  const text = prompt('Paste a JSON array of flows (as produced by "Copy as JSON"):');
  if (!text) return;
  try {
    const arr = JSON.parse(text);
    if (!Array.isArray(arr)) throw new Error('expected a JSON array');
    settings.actions = arr.map((a) => ({ ...ACTION_DEFAULTS, ...a }));
    await saveActions(true);
    toast(`Imported ${arr.length} flow(s).`);
  } catch (err) {
    toast(`Could not import: ${err.message}`, 6000);
  }
});

// ---------------------------------------------------------------- teaching

async function renderRules() {
  const rules = await getRules();
  $('rules').innerHTML = rules.length
    ? rules.slice().reverse().map((r) => `<div class="rule"><span class="pill ${r.kind === 'prefer' ? 'ok' : 'bad'}">${r.kind === 'prefer' ? 'use' : 'skip'}</span>
        <span class="grow" title="${esc(r.terms.join(', '))}"><b>${esc(r.path)}</b> <span class="muted">for: ${esc(r.terms.slice(0, 8).join(', '))}${r.sender ? ` · from ${esc(r.sender)}` : ''}</span></span>
        <button type="button" data-del-rule="${esc(r.id)}">Forget</button></div>`).join('')
    : '<p class="small muted">Nothing learned yet.</p>';
}

$('rules').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-del-rule]');
  if (!b) return;
  await deleteRule(b.dataset.delRule);
  renderRules();
});

let hintTimer = null;
$('hintPath').addEventListener('input', () => {
  clearTimeout(hintTimer);
  hintTimer = setTimeout(async () => {
    const q = $('hintPath').value.trim();
    if (q.length < 2) return;
    const res = await engine('search', { q, k: 15 });
    const paths = [...new Set((res?.hits || []).map((h) => h.path))];
    $('hintPaths').innerHTML = paths.map((p) => `<option value="${esc(p)}"></option>`).join('');
  }, 250);
});

$('addHint').addEventListener('click', async () => {
  const text = $('hintText').value.trim();
  const path = $('hintPath').value.trim();
  if (!(await get('files', path))) { $('hintOut').textContent = 'Pick a file from the suggestions (it must be in the index).'; return; }
  try {
    await addHint(text, path);
    $('hintOut').textContent = 'Hint added.';
    $('hintText').value = '';
    $('hintPath').value = '';
    renderRules();
  } catch (err) {
    $('hintOut').textContent = err.message;
  }
});

// ---------------------------------------------------------------- data

$('rebuildIndex').addEventListener('click', async () => {
  if (!confirm('Throw away the index and read every file again? Your files are not touched. Indexed Outlook emails and saved meetings are kept.')) return;
  const { resetIndex } = await import('./lib/index.js');
  await resetIndex();
  for (const k of ['indexStatus', 'deepApplied']) await kvSet(k, null);
  const res = await engine('index.run');
  toast(res?.error || 'Rebuilding the index…');
});
$('clearDrafts').addEventListener('click', async () => {
  if (!confirm('Clear the draft log? Outlook is not touched.')) return;
  await clear('items');
  engine('badge');
  toast('Draft log cleared.');
});
$('clearRules').addEventListener('click', async () => {
  if (!confirm('Forget everything the assistant has been taught about documents?')) return;
  await kvSet('rules', []);
  renderRules();
});

// ---------------------------------------------------------------- standing instructions

const SCOPE_LABEL = { all: 'everything', email: 'email drafts', meeting: 'meetings', chat: 'the chat' };

async function renderInstructions() {
  const list = await listInstructions();
  $('instList').innerHTML = list.length
    ? list.slice().reverse().map((i) => `<div class="rule"><span class="pill">${esc(SCOPE_LABEL[i.scope] || i.scope)}</span><span class="grow">${esc(i.text)}</span><button type="button" data-del-inst="${esc(i.id)}">Remove</button></div>`).join('')
    : '<p class="small muted">None yet.</p>';
}

$('addInst').addEventListener('click', async () => {
  const text = $('instText').value.trim();
  if (!text) return;
  await addInstruction(text, $('instScope').value);
  $('instText').value = '';
  settings = await getSettings();
  renderInstructions();
  flashSaved();
});
$('instList').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-del-inst]');
  if (!b) return;
  await removeInstruction(b.dataset.delInst);
  settings = await getSettings();
  renderInstructions();
});

// ---------------------------------------------------------------- export / import (moving to another computer)

const SECRET = new Set(['anthropicKey', 'geminiKey', 'localKey']);

$('exportSetup').addEventListener('click', async () => {
  const s = await getSettings();
  const out = Object.fromEntries(Object.entries(s).filter(([k]) => !SECRET.has(k) && k !== 'folderPrefs'));
  out.rules = await getRules();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify({ projectAssistantSettings: 1, at: new Date().toISOString(), settings: out }, null, 2)], { type: 'application/json' }));
  a.download = `project-assistant-settings-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
});

$('importSetup').addEventListener('click', () => {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'application/json,.json';
  inp.onchange = async () => {
    try {
      const data = JSON.parse(await inp.files[0].text());
      const incoming = data.settings || data;
      const patch = {};
      for (const [k, v] of Object.entries(incoming)) if (k in DEFAULT_SETTINGS && !SECRET.has(k) && k !== 'folderPrefs') patch[k] = v;
      settings = await saveSettings(patch);
      if (Array.isArray(incoming.rules)) await kvSet('rules', incoming.rules);
      fillFields();
      renderActions();
      renderRules();
      renderInstructions();
      toast(`Imported ${Object.keys(patch).length} settings.`);
    } catch (err) {
      toast(`Could not import: ${err.message}`, 6000);
    }
  };
  inp.click();
});

// ---------------------------------------------------------------- init

(async () => {
  settings = await getSettings();
  fillFields();
  renderNas();
  renderFolders();
  renderActions();
  renderRules();
  renderInstructions();
  renderAccuracy();
  renderSpend();
  renderLocalFor();
  renderModelPicker('anthropic');
  renderProjectMail();
  renderModelPicker('gemini');
  $('nasFolders').value = (settings.nasFolders || []).join('\n');
  if (location.hash) document.querySelector(location.hash)?.scrollIntoView();
})();
